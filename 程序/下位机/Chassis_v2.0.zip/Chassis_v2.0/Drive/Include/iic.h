#ifndef __IIC_H
#define __IIC_H

#include "stm32f4xx.h"

void SDA_OUT(void);
void SDA_IN(void);
void IIC_init(void);
void IIC_Start(void);
void IIC_Stop(void);
void IIC_ACK(void);
void IIC_NACK(void);
uint8_t IIC_waitACK(void);
void IIC_SendByte(uint8_t data);
uint8_t IIC_ReadByte(uint8_t ack);

#endif
