#ifndef __MOTOR_H
#define __MOTOR_H

#include "stm32f4xx.h"
#include <stdbool.h>

#define pi 3.14159f
#define COS_Omega 0.962218f
#define Wheel_Diameter 70.0f // mm

#define Forward 0
#define Backward 1
#define Left 2
#define Right 3

/*
MotorA
EN		PE0
STP		PA6   TIM13
DIR		PE4
*/
#define RCC_MotorA_EN 			RCC_AHB1Periph_GPIOE 	// �˿�ʱ��
#define MotorA_EN_PORT 			GPIOE               	// �˿�
#define MotorA_EN 				GPIO_Pin_0              // ����
#define RCC_MotorA_STP 			RCC_AHB1Periph_GPIOA 	
#define MotorA_STP_PORT 		GPIOA             	
#define MotorA_STP 				GPIO_Pin_6
#define MotorA_STP_SOURCE 		GPIO_PinSource6
#define RCC_MotorA_DIR 			RCC_AHB1Periph_GPIOE 	
#define MotorA_DIR_PORT 		GPIOE             	
#define MotorA_DIR 				GPIO_Pin_4

/*
MotorB
EN		PE1
STP		PA7   TIM14
DIR		PE5
*/
#define RCC_MotorB_EN 			RCC_AHB1Periph_GPIOE 	// �˿�ʱ��
#define MotorB_EN_PORT 			GPIOE               	// �˿�
#define MotorB_EN 				GPIO_Pin_1              // ����
#define RCC_MotorB_STP 			RCC_AHB1Periph_GPIOA 	
#define MotorB_STP_PORT 		GPIOA             	
#define MotorB_STP 				GPIO_Pin_7    
#define MotorB_STP_SOURCE 		GPIO_PinSource7
#define RCC_MotorB_DIR 			RCC_AHB1Periph_GPIOE 	
#define MotorB_DIR_PORT 		GPIOE             	
#define MotorB_DIR 				GPIO_Pin_5

/*
MotorC
EN		PE2
STP		PB0   TIM3
DIR		PE6
*/
#define RCC_MotorC_EN 			RCC_AHB1Periph_GPIOE 	// �˿�ʱ��
#define MotorC_EN_PORT 			GPIOE               	// �˿�
#define MotorC_EN 				GPIO_Pin_2              // ����
#define RCC_MotorC_STP 			RCC_AHB1Periph_GPIOB 	
#define MotorC_STP_PORT 		GPIOB             	
#define MotorC_STP 				GPIO_Pin_0    
#define MotorC_STP_SOURCE 		GPIO_PinSource0
#define RCC_MotorC_DIR 			RCC_AHB1Periph_GPIOE 	
#define MotorC_DIR_PORT 		GPIOE             	
#define MotorC_DIR 				GPIO_Pin_6

/*
MotorD
EN		PE3
STP		PA5   TIM2
DIR		PE7
*/
#define RCC_MotorD_EN 			RCC_AHB1Periph_GPIOE 	// �˿�ʱ��
#define MotorD_EN_PORT 			GPIOE               	// �˿�
#define MotorD_EN 				GPIO_Pin_3              // ����
#define RCC_MotorD_STP 			RCC_AHB1Periph_GPIOA 	
#define MotorD_STP_PORT 		GPIOA             	
#define MotorD_STP 				GPIO_Pin_5   
#define MotorD_STP_SOURCE 		GPIO_PinSource5
#define RCC_MotorD_DIR 			RCC_AHB1Periph_GPIOE 	
#define MotorD_DIR_PORT 		GPIOE             	
#define MotorD_DIR 				GPIO_Pin_7

extern int Pulse_Cnt;


void MotorA_Move(float speed);
void MotorB_Move(float speed);
void MotorC_Move(float speed);
void MotorD_Move(float speed);
void MotorA_Init(void);
void MotorB_Init(void);
void MotorC_Init(void);
void MotorD_Init(void);
void Motors_Init(void);

#endif
