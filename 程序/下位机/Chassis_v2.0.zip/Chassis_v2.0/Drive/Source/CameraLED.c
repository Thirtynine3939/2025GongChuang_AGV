#include "stm32f4xx.h"

void CamLED_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_AHB1PeriphClockCmd (RCC_AHB1Periph_GPIOC, ENABLE);

    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_OUT;   //输出模式
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;  //推挽输出
	GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;	//上拉
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz; //速度选择
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;	 
    GPIO_Init(GPIOC, &GPIO_InitStructure);

	GPIO_SetBits(GPIOC, GPIO_Pin_5);
}

void CamLED_Toggle(uint8_t sta)
{
    if(sta == 1)
    {
        GPIO_ResetBits(GPIOC, GPIO_Pin_5);
    }
    else if (sta == 0)
    {
        GPIO_SetBits(GPIOC, GPIO_Pin_5);
    }
    
}
