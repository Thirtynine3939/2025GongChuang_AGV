#ifndef __CAR_H
#define __CAR_H

// // 小车方向定义
// typedef enum 
// {
//     DIR_FORWARD = 0,
//     DIR_BACKWARD,
//     DIR_LEFT,
//     DIR_RIGHT,
//     // 后续新方向在此添加
// } Direction;

typedef struct 
{
    uint8_t		state;
    uint8_t     move_mode;
    float		Speed_X;
	float 		Speed_Y;
	float		Current_YawAngle; // 逆时针为正
    float       Current_YawAngle_Unlimited;
    float       set_yawangle;
    float       correction;
    uint16_t    current_time_count;
    uint16_t    last_x;
    uint16_t    last_y;
    uint16_t    back_X;
    uint16_t    back_Y;
    uint8_t     back_time;
    uint16_t    current_X;
    uint16_t    current_Y;
    uint8_t     rotate_limitspeed;
} CAR;

typedef struct 
{
    uint16_t    target_time_count_Total;
    float       Current_Speed_Total;
    float       Max_Speed_Total;
    float       X_Comp;
    float       Y_Comp;
}CarCtrl_Line;

typedef struct 
{
    uint16_t    target_time_count_X;
    uint16_t    target_time_count_Y;
    float       Current_Speed_X;
    float       Current_Speed_Y;
    float       Max_Speed_X;
    float       Max_Speed_Y;
}CarCtrl_Curve;

void Car_Move(float Speed_X, float Speed_Y, float Speed_Omega,float current_yawangle);
void Car_Enable(bool sta);
void Car_Absolute_Pos_Ctrl_Line(uint16_t target_x, uint16_t target_y, uint8_t time);
void Car_Relative_Pos_Ctrl_Line(int16_t rel_x, int16_t rel_y, uint8_t time);
void Car_Poscali_Start_or_Stop(uint8_t state);
void Car_Rotate(int16_t angle, uint8_t speed);

#endif
