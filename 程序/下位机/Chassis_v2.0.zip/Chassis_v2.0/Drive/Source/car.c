#include "task.h"

extern CAR car;
extern Flag flag;
extern PID_TypeDef pid;
extern PID_TypeDef pid_rotate;
extern CarCtrl_Line line;
extern CarCtrl_Curve curve;
extern JetsonData jsdata;
extern TxPack txpack;

float DIRs[4][2] = {{0.0f, 1.0f}, {0.0f, -1.0f}, {-1.0f, 0.0f}, {1.0f, 0.0f}};

//小车速度控制    // mm/s  mm/s  wrong  degree
void Car_Move(float Speed_X, float Speed_Y, float Speed_Omega,float current_yawangle)
{
	float speed_cal[4];
	float angle_in_radians = current_yawangle * (pi / 180.0f);
	float sin_ang = arm_sin_f32(angle_in_radians);
	float cos_ang = arm_cos_f32(angle_in_radians);
	float u = Speed_X * cos_ang + Speed_Y * sin_ang;
	float v = -Speed_X * sin_ang + Speed_Y * cos_ang;
	float u_rpm = (u/(Wheel_Diameter*pi)) * 60.0f;
	float v_rpm = (v/(Wheel_Diameter*pi)) * 60.0f;
	float speed_omega_cal = Speed_Omega*30/pi * 0.153f;
    speed_cal[0] = + 0.707107f * u_rpm - 0.707107f * v_rpm + speed_omega_cal;
	speed_cal[1] = - 0.707107f * u_rpm - 0.707107f * v_rpm + speed_omega_cal;
	speed_cal[2] = - 0.707107f * u_rpm + 0.707107f * v_rpm + speed_omega_cal;
	speed_cal[3] = + 0.707107f * u_rpm + 0.707107f * v_rpm + speed_omega_cal;
	MotorA_Move(speed_cal[0]);
	MotorB_Move(speed_cal[1]);
	MotorC_Move(speed_cal[2]);
	MotorD_Move(speed_cal[3]);
}

void Car_Rotate(int16_t angle, uint8_t speed) // 逆时针为正
{
	if(angle < -180 || angle > 180) return;
	if(flag.car_in_task == 0)
	{
		// PID_Init(&pid, 1.5f, 0.00001f, 0.1f, (float)angle, 0.01f);
		pid_rotate.setpoint = (float)angle;
		car.set_yawangle = (float)angle;
		car.rotate_limitspeed = speed;
		flag.car_in_task = 3;
	}
	// flag.car_in_task = 3;	// 3：旋转模式

}

void Car_Poscali_Start_or_Stop(uint8_t state)
{
	if(state == 1)
	{
		flag.car_in_task = 2;	// 2: 定位校准模式
	}
	else if(state == 0)
	{
		flag.car_in_task = 0;
		jsdata.circle_x = 0;
		jsdata.circle_y = 0;
		txpack.floats[1] = jsdata.circle_x;
        txpack.floats[2] = jsdata.circle_y;
	}
}

void Car_Enable(bool sta)
{
	if(sta)
	{
		GPIO_ResetBits(MotorA_EN_PORT,MotorA_EN);
		GPIO_ResetBits(MotorB_EN_PORT,MotorB_EN);
		GPIO_ResetBits(MotorC_EN_PORT,MotorC_EN);
		GPIO_ResetBits(MotorD_EN_PORT,MotorD_EN);
	}
	else
	{
		GPIO_SetBits(MotorA_EN_PORT,MotorA_EN);
		GPIO_SetBits(MotorB_EN_PORT,MotorB_EN);
		GPIO_SetBits(MotorC_EN_PORT,MotorC_EN);
		GPIO_SetBits(MotorD_EN_PORT,MotorD_EN);
	}
}

void Car_Absolute_Pos_Ctrl_Line(uint16_t target_x, uint16_t target_y, uint8_t time) // 单位：mm  mm  0.1s
{
	pid.integral = 0;
	pid.previous_error = 0;
	// static uint16_t last_x,last_y;
	float distance;
	arm_sqrt_f32((float)((target_x-car.last_x)*(target_x-car.last_x) + (target_y-car.last_y)*(target_y-car.last_y)), &distance);

	if(distance < 1.0f || time == 0 || flag.car_in_task == 1) return;

	car.current_X = target_x;
	car.current_Y = target_y;
	car.back_X = car.last_x;
	car.back_Y = car.last_y;
	car.back_time = time;
	line.Max_Speed_Total = (float)(1.02f * distance + 2.0f)/((float)time/20.0f);
	line.target_time_count_Total = time * 20;
	line.X_Comp = (int)(target_x - car.last_x)/distance;
	line.Y_Comp = (int)(target_y - car.last_y)/distance;
	car.move_mode = LINE;
    flag.car_in_task = 1;
    Move_Time_Cmd(1);
	car.last_x = target_x;
	car.last_y = target_y;
}

void Car_Relative_Pos_Ctrl_Line(int16_t rel_x, int16_t rel_y, uint8_t time) // 单位：mm  /  0.1s
{
	pid.integral = 0;
	pid.previous_error = 0;
	float distance;
	arm_sqrt_f32((float)(rel_x*rel_x + rel_y*rel_y), &distance);

	if(distance < 1.0f || time == 0 || flag.car_in_task == 1) return;

    line.Max_Speed_Total = (float)(1.02f * distance + 2.0f)/((float)time/20.0f);
    line.target_time_count_Total = time * 20;
    line.X_Comp = (int)(rel_x)/distance;
    line.Y_Comp = (int)(rel_y)/distance;
    car.move_mode = LINE;
    flag.car_in_task = 1;
    Move_Time_Cmd(1);
}


