#include "task.h"

//���ö�ʱ����TIM2 TIM3 TIM4 TIM10 TIM11 TIM12 TIM13 TIM14 

RxPack rxpack;
TxPack txpack;
PID_TypeDef pid;
PID_TypeDef pid_poscali;
PID_TypeDef pid_rotate;
CAR car;
Flag flag;
ButtonID btn;
CarCtrl_Line line;
CarCtrl_Curve curve;
JetsonData jsdata;
JetsonFlag jsflag;
PosCali poscali;
ZeroBiasCal zbc;

int main(void)
{
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	LED_Init();
	LED1_OFF;
	delay_init(168);
	Key_Init();
	CamLED_Init();
	Servo_Init();
	PID_Init(&pid, 4.2f, 0.16f, 0.3f, 0.0f, 0.01f);    	// ��ʼ��yaw��PID����
	PID_Init(&pid_poscali, 2.0f, 0.0001f, 1.0f, 0.0f, 2.0f);    	// ��ʼ��С���Ӿ���λУ׼PID����
	PID_Init(&pid_rotate, 2.0f, 0.001f, 0.3f, 0.0f, 0.01f); 
	Bluetooth_Init_U2(115200);
	HWT101_Init_U4();
	Jetson_Init_U5();
	Motors_Init();
	Move_Time_TIM12_Init(84, 5000);  //0.005s
	Task_Backend_TIM11_Init(168, 1000);  //0.001s
	ZerobiasCali_TIM10_Init(16800, 10000); //1s
	OLED_Init();
	printf("test1");
	
	//�����ʼ��
	cPID_En = 1;
	OLED_ShowString(1, 1, "Please Press");
	OLED_ShowString(2, 1, "The Button. ");
	while (1)
	{
		Task_Handler();
		Button_Scan_Task();
		
		switch(btn) 
		{
            case BTN_YAW_SETZERO:
				GyroYaw_SetZero();
				pid.integral = 0;
				pid.previous_error = 0;
                break;
            case BTN_P_A_L_MOVE:
				Car_Absolute_Pos_Ctrl_Line(P_A_L_x, P_A_L_y, P_A_L_t);
                break;
			case BTN_P_R_L_MOVE:
				Car_Relative_Pos_Ctrl_Line(P_R_L_x, P_R_L_y, P_R_L_t);
				break;
			case BTN_BACK:
				Car_Absolute_Pos_Ctrl_Line(car.back_X, car.back_Y, car.back_time);
				break;
			case BTN_APOS_SETZERO:
				car.last_x = 0;
				car.last_y = 0;
				break;
			case BTN_ZEROBIASCALI:
				ZerobiasCal_Start(22);
				break;
			case BTN_PGUP:
				if(point_num == 0)
				{
					point_num = 15;
				}
				else
				{
					point_num--;
				}
				break;
			case BTN_PGDN:
				if(point_num == 16)
				{
					point_num = 0;
				}
				else
				{
					point_num++;
				}
				break;
			case BTN_SAVE:
				point_XYt_array[point_num][0] = Set_X;
				point_XYt_array[point_num][1] = Set_Y;
				point_XYt_array[point_num][2] = Set_Time;
				break;
			case BTN_P_NEXT:
				if(P_mode)
				{
					if(flag.car_in_task == 0)
					{
						point_num++;
						if(point_num >= 16) point_num = 16;
						Car_Relative_Pos_Ctrl_Line(point_XYt_array[point_num][0], point_XYt_array[point_num][1], point_XYt_array[point_num][2]);
					}
				}
				break;
			case BTN_P_BACK:
				if(P_mode)
				{
					if(flag.car_in_task == 0)
					{
						
						Car_Relative_Pos_Ctrl_Line(-point_XYt_array[point_num][0], -point_XYt_array[point_num][1], point_XYt_array[point_num][2]);
						if(point_num == 0)
						{
							point_num = 0;
						}
						else
						{
							point_num--;
						}
					}
				}
				break;
			case BTN_ARMTO1:
				PoscaliDirChoose(1);
                break;
			case BTN_ARMTO2:
				PoscaliDirChoose(2);
                break;
			case BTN_ARMTO3:
				PoscaliDirChoose(3);
                break;
			case BTN_ARMTO4:
				PoscaliDirChoose(4);
                break;
			case BTN_ROTATE:
				Car_Rotate(SetAngle, ro_v_limit);
				break;
        }
	}
	
}

void TIM8_BRK_TIM12_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM12, TIM_IT_Update) == SET)
	{
		TIM_ClearITPendingBit(TIM12, TIM_IT_Update);
		car.current_time_count++;
	}
}

void TIM1_TRG_COM_TIM11_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM11, TIM_IT_Update) == SET)
	{
		TIM_ClearITPendingBit(TIM11, TIM_IT_Update);
		TaskSchedule();
	}
}

void TIM1_UP_TIM10_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM10, TIM_IT_Update) == SET)
	{
		TIM_ClearITPendingBit(TIM10, TIM_IT_Update);
		zbc.secondsCounter++;
	}
}
