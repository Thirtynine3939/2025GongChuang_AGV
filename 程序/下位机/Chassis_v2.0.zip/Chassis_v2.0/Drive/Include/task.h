#ifndef __TASK_H
#define __TASK_H

#include "stm32f4xx.h"
#include "arm_math.h"
#include "delay.h"
#include "Timer.h"
#include "pid.h"
#include "motor.h"
#include "car.h"
#include "Servo.h"
#include "jetson.h"
#include "valuepack.h"
#include "hwt101.h"
#include <stdbool.h>
#include "button_scan.h"
#include "CameraLED.h"
#include "OLED.h"
#include "Key.h"
#include <math.h>
#include "led.h"

#define LINE 0
#define CURVE 1

typedef struct 
{
    uint8_t run;            //调度标志， 1：调度，0：挂起
    uint16_t TimeCount;     //时间片周期，用于递减计数
    uint16_t TimeReload;    //时间片周期，用于重载
    void (*pTaskFunc)(void);//函数指针，保存任务函数地址
}TaskComps_t;


typedef struct 
{
    uint8_t     motor_en;
    uint8_t     poscali_en;
    uint8_t     camled_en;
    uint8_t     car_in_task;
    uint8_t     curve_X;
    uint8_t     curve_Y;
    uint8_t     cycle_move;
    uint8_t     total_init;
} Flag;

typedef struct 
{
    float     distance;
} PosCali;

extern uint8_t point_num;
extern int16_t point_XYt_array[17][3];

void Task_Handler(void);
void TaskSchedule(void);
void ZerobiasCal_Handle_Task(void);
void Car_En_Switch_Task(void);
void Bluetooth_Data_Send_Task(void);
void PID_En_Switch_Task(void);
void Joystick_Ctrl_Car_Task(void);
void Move_Ctrl_Task(void);
void Jetson_Cmd_Receive_Task(void);
void Car_Poscali_Task(void);
void PosCali_En_Switch_Task(void);
void CamLED_En_Switch_Task(void);
void CycleMove_En_Switch_Task(void);
void KeyCheck_Task(void);
void CarRotate_Task(void);

#endif
