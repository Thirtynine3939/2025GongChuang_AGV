#include "stm32f4xx.h"               // Device header

void Servo_PWM_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_OCInitTypeDef TIM_OCInitStructure;
	
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
	
	//GPIO����
	GPIO_InitStructure.GPIO_Pin 		= GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Mode 		= GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_OType  		= GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed 		= GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_PuPd		= GPIO_PuPd_DOWN;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
	
	GPIO_PinAFConfig(GPIOD, GPIO_PinSource12, GPIO_AF_TIM4);
	GPIO_PinAFConfig(GPIOD, GPIO_PinSource13, GPIO_AF_TIM4);
	GPIO_PinAFConfig(GPIOD, GPIO_PinSource14, GPIO_AF_TIM4);
	GPIO_PinAFConfig(GPIOD, GPIO_PinSource15, GPIO_AF_TIM4);
	
	//��ʱ��
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_ClockDivision = 0;
	TIM_TimeBaseInitStructure.TIM_Prescaler = 84 - 1;		//PSC
	TIM_TimeBaseInitStructure.TIM_Period = 20000 - 1;	    //ARR	50Hz
	TIM_TimeBaseInit(TIM4, &TIM_TimeBaseInitStructure);
	
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; //PWMģʽ1������CCRʱΪ��Ч��ƽ
 	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; //����Ƚ�ʹ��
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; //��Ч��ƽΪ�ߵ�ƽ
	TIM_OCInitStructure.TIM_Pulse = 0;		//CCR
	TIM_OC1Init(TIM4, &TIM_OCInitStructure);
	TIM_OC2Init(TIM4, &TIM_OCInitStructure);
	TIM_OC3Init(TIM4, &TIM_OCInitStructure);
	TIM_OC4Init(TIM4, &TIM_OCInitStructure);
	TIM_OC1PreloadConfig(TIM4, TIM_OCPreload_Enable);
	TIM_OC2PreloadConfig(TIM4, TIM_OCPreload_Enable);
	TIM_OC3PreloadConfig(TIM4, TIM_OCPreload_Enable);
	TIM_OC4PreloadConfig(TIM4, TIM_OCPreload_Enable);
//	TIM_Cmd(TIM4, ENABLE);
}

void Servo_SetAngle(uint8_t addr, float Angle)
{
	switch (addr)
	{
	case 1:
		TIM_SetCompare1(TIM4, (uint16_t)(Angle / 270 * 2000 + 500));
		break;
	case 2:
		TIM_SetCompare2(TIM4, (uint16_t)(Angle / 270 * 2000 + 500));
		break;
	case 3:
		TIM_SetCompare3(TIM4, (uint16_t)(Angle / 270 * 2000 + 500));
		break;
	case 4:
		TIM_SetCompare4(TIM4, (uint16_t)(Angle / 270 * 2000 + 500));
		break;
	}
	
}

void Servo_Init(void)
{
	Servo_PWM_Init();
	Servo_SetAngle(1, 215.0);//max:258
	Servo_SetAngle(2, 150.6);//max:180.6
	Servo_SetAngle(3, 268.0);//267.8  174.3  90.0  48.0  132.0
	Servo_SetAngle(4, 124.0);//max:210  mid:131 min:43
	TIM_Cmd(TIM4, ENABLE);
}

//void Gripper_Enable(uint8_t a)
//{
//	if(!a){Servo_SetAngle(102);}
//	else {Servo_SetAngle(77.5);}
//}
