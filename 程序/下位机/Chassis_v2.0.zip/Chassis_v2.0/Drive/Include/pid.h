#ifndef __PID_H
#define __PID_H

#include "stm32f4xx.h" 

typedef struct {
    float Kp;
    float Ki;
    float Kd;
    float setpoint;
    float integral;
    float previous_error;
    float allowed_error;
} PID_TypeDef;

void PID_Init(PID_TypeDef* pid, float kp, float ki, float kd, float setpoint, float allowed_error);
float PID_Compute(PID_TypeDef* pid, float current_value);

#endif
