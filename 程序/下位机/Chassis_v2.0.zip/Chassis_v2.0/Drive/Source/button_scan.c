#include "task.h"

extern RxPack rxpack;
extern TxPack txpack;
extern PID_TypeDef pid;
extern PID_TypeDef pid_poscali;
extern PID_TypeDef pid_rotate;
extern CAR car;
extern Flag flag;
extern ButtonID btn;

//�����������ݱ���
bool P_A_L_Move, P_R_L_Move, Back, Yaw_SetZero, PID_En, World_En, Apos_SetZero,
     cPID_En, ZerobiasCali, PGUP, PGDN, SAVE, P_mode, P_NEXT, P_BACK, ArmTo1, ArmTo2, 
     ArmTo3, ArmTo4, PosCali_en, CamLED_en, CycleMove_en, rotate = 0;
bool Motor_En = true;
uint8_t P_A_L_t, P_R_L_t, Set_Time = 0;
uint16_t P_A_L_x, P_A_L_y, Set_X, Set_Y, ro_v_limit = 0;
int16_t Speed_X_x10, Speed_Y_x10, Kp_x1000, Ki_x1000, Kd_x1000, cKp_x1000, cKi_x10000, cKd_x1000, P_R_L_x, P_R_L_y, SetAngle = 0;


typedef struct 
{
    bool        *button; // ��ť����ָ��
    ButtonID    retVal; // ��Ӧ�ķ���ֵ
} ButtonMap;

// ��ťӳ�������app��˳�����У�
static const ButtonMap buttonMap[] = 
{
    {&P_A_L_Move,       BTN_P_A_L_MOVE},
    {&P_R_L_Move,       BTN_P_R_L_MOVE},
    {&Back,             BTN_BACK},
    {&Yaw_SetZero,      BTN_YAW_SETZERO},
    {&Apos_SetZero,     BTN_APOS_SETZERO},
    {&ZerobiasCali,     BTN_ZEROBIASCALI},
    {&PGUP,             BTN_PGUP},
    {&PGDN,             BTN_PGDN},
    {&SAVE,             BTN_SAVE},
    {&P_NEXT,           BTN_P_NEXT},
    {&P_BACK,           BTN_P_BACK},
    {&ArmTo1,           BTN_ARMTO1},
    {&ArmTo2,           BTN_ARMTO2},
    {&ArmTo3,           BTN_ARMTO3},
    {&ArmTo4,           BTN_ARMTO4},
    {&rotate,           BTN_ROTATE}
    // �����°�ť�ڴ˴�׷��...
};

void Button_Scan_Task(void)
{
    static uint8_t allowTrigger = 1;
    
    // ����������ʱ��ⰴť
    if(allowTrigger)
    {
        // �������а�ť
        for(uint8_t i = 0; i < sizeof(buttonMap)/sizeof(ButtonMap); i++)
        {
            if(*buttonMap[i].button)
            {
                allowTrigger = 0; // ����ֱ�����а�ť�ͷ�
                btn = buttonMap[i].retVal;
				return;
            }
        }
    }
    // ����ֹ����ʱ����Ƿ�ȫ���ͷ�
    else
    {
        uint8_t allReleased = 1;
        
        // ������а�ť�Ƿ����ͷ�
        for(uint8_t i = 0; i < sizeof(buttonMap)/sizeof(ButtonMap); i++)
        {
            if(*buttonMap[i].button)
            {
                allReleased = 0;
                break; // ����δ�ͷŰ�ť����ǰ�˳�
            }
        }
        
        if(allReleased)
        {
            allowTrigger = 1; // �����´δ���
        }
    }
    
    btn = BTN_NONE;
}

void Bluetooth_Data_Receive_Task(void)
{
    if(readValuePack(&rxpack))
    {
        P_A_L_Move      =   rxpack.bools[0] & 0x1;
        P_R_L_Move      =   (rxpack.bools[0]>>1) & 0x1;
        Back            =   (rxpack.bools[0]>>2) & 0x1;
        Yaw_SetZero     =   (rxpack.bools[0]>>3) & 0x1;
        PID_En          =   (rxpack.bools[0]>>4) & 0x1;
        World_En        =   (rxpack.bools[0]>>5) & 0x1;
        Motor_En        =   (rxpack.bools[0]>>6) & 0x1;
        Apos_SetZero    =   (rxpack.bools[0]>>7) & 0x1;
        cPID_En         =   rxpack.bools[1] & 0x1;
        ZerobiasCali    =   (rxpack.bools[1]>>1) & 0x1;
        PGUP            =   (rxpack.bools[1]>>2) & 0x1;
        PGDN            =   (rxpack.bools[1]>>3) & 0x1;
        SAVE            =   (rxpack.bools[1]>>4) & 0x1;
        P_mode          =   (rxpack.bools[1]>>5) & 0x1;
        P_NEXT          =   (rxpack.bools[1]>>6) & 0x1;
        P_BACK          =   (rxpack.bools[1]>>7) & 0x1;
        ArmTo1          =   rxpack.bools[2] & 0x1;
        ArmTo2          =   (rxpack.bools[2]>>1) & 0x1;
        ArmTo3          =   (rxpack.bools[2]>>2) & 0x1;
        ArmTo4          =   (rxpack.bools[2]>>3) & 0x1;
        PosCali_en      =   (rxpack.bools[2]>>4) & 0x1;
        CamLED_en       =   (rxpack.bools[2]>>5) & 0x1;
        CycleMove_en    =   (rxpack.bools[2]>>6) & 0x1;
        rotate          =   (rxpack.bools[2]>>7) & 0x1;
        P_A_L_t         =   rxpack.bytes[0];
        P_R_L_t         =   rxpack.bytes[1];
        Set_Time        =   rxpack.bytes[2];
        P_A_L_x         =   rxpack.shorts[0];
        P_A_L_y         =   rxpack.shorts[1];
        P_R_L_x         =   rxpack.shorts[2];
        Speed_X_x10     =   rxpack.shorts[3];
        Speed_Y_x10     =   rxpack.shorts[4];
        Kp_x1000        =   rxpack.shorts[5];
        Ki_x1000        =   rxpack.shorts[6];
        Kd_x1000        =   rxpack.shorts[7];
        cKp_x1000       =   rxpack.shorts[8];
        cKi_x10000      =   rxpack.shorts[9];
        cKd_x1000       =   rxpack.shorts[10];
        Set_X           =   rxpack.shorts[11];
        Set_Y           =   rxpack.shorts[12];
        P_R_L_y         =   rxpack.shorts[13];
        SetAngle        =   rxpack.shorts[14];
        ro_v_limit      =   rxpack.shorts[15];
        
        car.Speed_X = (float)Speed_X_x10/10.0f;
        car.Speed_Y = (float)Speed_Y_x10/10.0f;
        pid_rotate.Kp = (float)Kp_x1000/1000.0f;
        pid_rotate.Ki = (float)Ki_x1000/1000.0f;
        pid_rotate.Kd = (float)Kd_x1000/1000.0f;
        pid_poscali.Kp = (float)cKp_x1000/1000.0f;
        pid_poscali.Ki = (float)cKi_x10000/10000.0f;
        pid_poscali.Kd = (float)cKd_x1000/1000.0f;
    }
}


