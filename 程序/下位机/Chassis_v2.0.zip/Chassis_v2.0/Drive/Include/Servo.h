#ifndef __SERVO_H
#define __SERVO_H

#include "stm32f4xx.h"               // Device header

void Servo_Init(void);
void Servo_SetAngle(uint8_t addr, float Angle);
//void Gripper_Enable(uint8_t a);

#endif
