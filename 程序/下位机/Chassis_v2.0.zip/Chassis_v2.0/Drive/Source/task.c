#include "task.h"

extern TxPack txpack;
extern CAR car;
extern Flag flag;
extern PID_TypeDef pid;
extern PID_TypeDef pid_poscali;
extern PID_TypeDef pid_rotate;
extern CarCtrl_Line line;
extern CarCtrl_Curve curve;
extern JetsonData jsdata;
extern JetsonFlag jsflag;
extern PosCali poscali;
extern ZeroBiasCal zbc;

uint8_t point_num = 0;

//int16_t point_XYt_array[17][3] = {
//    {0, 0, 0},         //0

//    {0, 139, 15},      //1

//    {650, 0, 18},      //2

//    {800,0, 25},      //3

//    {-415, 0 ,16},      //4

//    {0, 1751, 42},      //5 前往暂存区

//    {845, 0, 24},       //6 

//    {0, -860, 24},      //7 

//    {0, -915, 24},      //8

//    {-430, 0, 24},      //9

//    {-415, 0, 16},      //10

//    {0, 1760, 42},      //11

//    {845, 0, 24},      //12

//    {0, -860, 24},      //13

//    {0, -915, 24},      //14

//    {-1880, 0, 40},      //15
//	{0, -100, 10}

//    // {0, 139, 40},       //15
//    // {0, 0, 10}
//};

int16_t point_XYt_array[17][3] = {
    {0, 0, 0},         //0

    {0, 139, 10},      //1

    {659, 0, 18},      //2

    {800,0, 25},        //3

    {-400, 0 ,16},      //4

    {0, 1738, 42},       //5 前往暂存区

    {827, 0, 24},       //6 

    {0, -827, 24},      //7 

    {0, -908, 24},      //8

    {-427, 0, 24},      //9

    {-400, 0, 16},      //10

    {0, 1738, 42},      //11

    {827, 0, 24},      //12

    {0, -827, 24},      //13

    {0, -911, 24},      //14

    {-1872, 0, 42},      //15

	{0, -130, 10}       //16
};

static TaskComps_t TaskComps[] =
{
    {0, 10, 10, Bluetooth_Data_Receive_Task},   //蓝牙数据接收
//    {0, 8, 8, Button_Scan_Task},              //app按键扫描
    {0, 5, 5, Yaw_Receive_Task},                //更新Yaw角
	{0, 5, 5, Car_En_Switch_Task},              //小车使能切换扫描
    {0, 50, 50, Bluetooth_Data_Send_Task},      //蓝牙数据发送
    {0, 10, 10, PID_En_Switch_Task},              //PID使能切换
    {0, 1, 1, Joystick_Ctrl_Car_Task},          //摇杆控制小车
    {0, 1, 1, Move_Ctrl_Task},                  //加减速移动控制任务状态机，直线、曲线
    {0, 1, 1, Jetson_Cmd_Receive_Task},         //Jetson指令接收
    {0, 1, 1, Car_Poscali_Task},                //小车视觉定位校准
    {0, 100, 100, ZerobiasCal_Handle_Task},     //零偏校准计时
    {0, 5, 5, PosCali_En_Switch_Task},          //小车视觉定位校准使能切换
    {0, 50, 50, CamLED_En_Switch_Task},            //摄像机补光灯使能切换
    {0, 500, 500, CycleMove_En_Switch_Task},
    {0, 5, 5, KeyCheck_Task},
    {0, 1, 1, CarRotate_Task}
};

void Task_Handler(void)
{
    for(uint8_t i = 0; i < sizeof(TaskComps)/sizeof(TaskComps_t); i++)
    {
        if(TaskComps[i].run) //判断是否需要调度
        {
            TaskComps[i].run = 0; //标志位挂起
            TaskComps[i].pTaskFunc(); //执行调度任务
        }
    }
}

void TaskSchedule(void)
{
    for(uint8_t i = 0; i < sizeof(TaskComps)/sizeof(TaskComps_t); i++)
    {
        if(TaskComps[i].TimeCount) //判断时间片计数
        {
            TaskComps[i].TimeCount--; //时间片计数递减
            if(TaskComps[i].TimeCount == 0)
            {
                TaskComps[i].TimeCount = TaskComps[i].TimeReload; //重载计数值
                TaskComps[i].run = 1;
            }
        }
    }
}

void KeyCheck_Task(void)
{
    uint8_t KeyNum = Key_GetNum();
    if(KeyNum == 1) // 按键1按下后开始零偏校准，或在校准中中止校准
    {
        if(zbc.isActive) // 如果正在进行零偏校准，则中止校准
        {
            LED1_OFF;
            // 中止零偏校准，提前执行完成处理
            UART4_SendArray(nomal_mode, sizeof(nomal_mode)); // 结束零偏校准
            zbc.secondsCounter = 0;
            zbc.isActive = 0;
            TIM_Cmd(TIM10, DISABLE);
            txpack.bytes[0] = 39;
            zbc.finish_flag = 1;
            
            // 设置用户中止标志，用于显示不同信息
            flag.total_init = 0; // 确保下面的完成处理会执行
        }
        else // 如果没有在校准，则开始零偏校准
        {
            LED1_ON;
            flag.total_init = 0;
            GyroYaw_SetZero(); // 陀螺仪Yaw角归零
            ZerobiasCal_Start(22); // 22秒零偏校准
            zbc.finish_flag = 0;
            OLED_ShowString(1, 1, "Gyroscope Is");
            OLED_ShowString(2, 1, "Calibrating.");
            OLED_ShowString(3, 1, "            ");
        }
    }
    if(zbc.finish_flag == 1 && !flag.total_init)
    {
        flag.total_init = 1;
        GyroYaw_SetZero();
        
        // 检查是否是用户手动中止的校准
        if(zbc.elapsedSeconds < zbc.waitSeconds && zbc.waitSeconds > 0)
        {
            // 用户手动中止的情况
            OLED_ShowString(1, 1, "Cal Finished");
            OLED_ShowString(2, 1, "By User.    ");
        }
        else
        {
            // 正常完成的情况
            OLED_ShowString(1, 1, "Calibration ");
            OLED_ShowString(2, 1, "Finished.   ");
        }
        
        PID_En = 1;
        OLED_ShowString(3, 1, "Ready to go!");
    }

    if(KeyNum == 2)
    {
        UART4_SendArray(restart_device, sizeof(restart_device));
    }
}

void ZerobiasCal_Handle_Task(void)
{
    if (!zbc.isActive) return;

    uint16_t currentSeconds = zbc.secondsCounter;
    zbc.elapsedSeconds = currentSeconds - zbc.startSeconds;
    
    // 实时更新秒数
    txpack.bytes[0] = zbc.elapsedSeconds;

    // 超时处理
    if (zbc.elapsedSeconds >= zbc.waitSeconds) 
    {
        UART4_SendArray(nomal_mode, sizeof(nomal_mode)); // 结束零偏校准
        zbc.secondsCounter = 0;
        zbc.isActive = 0;
        TIM_Cmd(TIM10, DISABLE);
		txpack.bytes[0] = 39;
        zbc.finish_flag = 1;
        LED1_OFF;
    }
}

void Car_En_Switch_Task(void)
{
    if(Motor_En && !flag.motor_en)
		{
			Car_Enable(Motor_En);
			flag.motor_en = true;
		}
		else if(!Motor_En && flag.motor_en)
		{
			Car_Enable(Motor_En);
			flag.motor_en = false;
		}
}

void Bluetooth_Data_Send_Task(void)
{
    txpack.bytes[1] = point_num;
    txpack.bytes[2] = point_XYt_array[point_num][2]; //point_time
    txpack.shorts[0] = point_XYt_array[point_num][0]; //point_X
    txpack.shorts[1] = point_XYt_array[point_num][1]; //point_Y 
	sendValuePack(&txpack);
}

void PID_En_Switch_Task(void)
{
    if(PID_En)
    {
        if(flag.car_in_task != 3)
        {
            car.correction = PID_Compute(&pid, car.Current_YawAngle_Unlimited);
        }
        else
        {
            car.correction = PID_Compute(&pid_rotate, car.Current_YawAngle_Unlimited);
            if(car.correction > car.rotate_limitspeed) car.correction = car.rotate_limitspeed;
            else if(car.correction < -car.rotate_limitspeed) car.correction = -car.rotate_limitspeed;
        }
    }
    else if(!PID_En)
    {
        car.correction = 0;
    }
}

void Joystick_Ctrl_Car_Task(void)
{
    if(flag.car_in_task == 0 || (flag.car_in_task == 2 && cPID_En == 0) || flag.car_in_task == 3)
    {
        Car_Move(car.Speed_X, car.Speed_Y, car.correction, car.Current_YawAngle);
    }
}

void Move_Ctrl_Task(void)
{
    if(flag.car_in_task == 1)
    {
        if(car.move_mode == LINE)
        {
            if(car.current_time_count <= line.target_time_count_Total/2)
            {
                line.Current_Speed_Total = (line.Max_Speed_Total * car.current_time_count)/(line.target_time_count_Total/2);
            }
            else if(car.current_time_count <= line.target_time_count_Total)
            {
                line.Current_Speed_Total = line.Max_Speed_Total - ((line.Max_Speed_Total * (car.current_time_count - line.target_time_count_Total/2))
                                                                    /(line.target_time_count_Total/2));
            }
            else
            {
                Jetson_SendArray(CarReached, sizeof(CarReached));
                line.Current_Speed_Total = 0;
                flag.car_in_task = 0;
                Move_Time_Cmd(0);
                car.current_time_count = 0;
            }
            Car_Move(line.Current_Speed_Total * line.X_Comp, line.Current_Speed_Total * line.Y_Comp, car.correction, car.Current_YawAngle * (float)World_En);
        }
        else if(car.move_mode == CURVE)
        {
            if(car.current_time_count <= curve.target_time_count_X/2)
            {
                curve.Current_Speed_X = (curve.Max_Speed_X * car.current_time_count)/(curve.target_time_count_X/2);
            }
            else if(car.current_time_count <= curve.target_time_count_X)
            {
                curve.Current_Speed_X = curve.Max_Speed_X - ((curve.Max_Speed_X * (car.current_time_count - curve.target_time_count_X/2))
                                                                    /(curve.target_time_count_X/2));
            }
            else
            {
                curve.Current_Speed_X = 0;
                flag.curve_X = 1;
            }

            if(car.current_time_count <= curve.target_time_count_Y/2)
            {
                curve.Current_Speed_Y = (curve.Max_Speed_Y * car.current_time_count)/(curve.target_time_count_Y/2);
            }
            else if(car.current_time_count <= curve.target_time_count_Y)
            {
                curve.Current_Speed_Y = curve.Max_Speed_Y - ((curve.Max_Speed_Y * (car.current_time_count - curve.target_time_count_Y/2))
                                                                    /(curve.target_time_count_Y/2));
            }
            else
            {
                curve.Current_Speed_Y = 0;
                flag.curve_Y = 1;
            }

            if(flag.curve_X == 1 && flag.curve_Y == 1)
            {
                flag.curve_X = 0;
                flag.curve_Y = 0;
                flag.car_in_task = 0;
                Move_Time_Cmd(0);
                car.current_time_count = 0;
            }
            Car_Move(curve.Current_Speed_X, curve.Current_Speed_Y, car.correction, car.Current_YawAngle * (float)World_En);
        }
    }
}

void Car_Poscali_Task(void)
{
    if (flag.car_in_task == 2)
    {
        float distance;
        arm_sqrt_f32(jsdata.circle_x * jsdata.circle_x + jsdata.circle_y * jsdata.circle_y, &distance);
        txpack.floats[3] = distance;

        if (cPID_En == 1)
        {
            // 避免除零错误：当 distance 接近零时直接停止车辆
            if (distance < 1e-6f)
            {
                Car_Move(0, 0, car.correction, car.Current_YawAngle);
                return;
            }

            float speed_total = -PID_Compute(&pid_poscali, distance);

            // 根据方向计算分量
            float dir_x = 0.0f, dir_y = 0.0f;
            switch (jsdata.poscali_dir)
            {
                case 1:
                    dir_x = -speed_total * jsdata.circle_x / distance;
                    dir_y = -speed_total * jsdata.circle_y / distance;
                    break;
                case 2:
                    dir_x = speed_total * jsdata.circle_x / distance;
                    dir_y = speed_total * jsdata.circle_y / distance;
                    break;
                case 3:
                    dir_x = speed_total * jsdata.circle_y / distance;
                    dir_y = -speed_total * jsdata.circle_x / distance;
                    break;
                case 4:
                    dir_x = -speed_total * jsdata.circle_y / distance;
                    dir_y = speed_total * jsdata.circle_x / distance;
                    break;
            }

            // 执行移动
            Car_Move(dir_x, dir_y, car.correction, car.Current_YawAngle);
        }
    }
}

void Jetson_Cmd_Receive_Task(void)
{
    if(new_srevocmd_received)
    {
        Servo_SetAngle(new_srevocmd_received, ServoAngle[new_srevocmd_received - 1]);
        // printf("Servo1: %.2f degrees\r\n", ServoAngle[0]);
        // printf("Servo2: %.2f degrees\r\n", ServoAngle[1]);
        // printf("Servo3: %.2f degrees\r\n", ServoAngle[2]);
        // printf("Servo4: %.2f degrees\r\n", ServoAngle[3]);
        new_srevocmd_received = 0;
    }
    if(jsflag.new_linemove_cmd_received)
    {
        Car_Absolute_Pos_Ctrl_Line(jsdata.Line_X, jsdata.Line_Y, jsdata.Line_time);
        jsflag.new_linemove_cmd_received = 0;
    }
    if(jsflag.new_relmove_cmd_received)
    {
        Car_Relative_Pos_Ctrl_Line(jsdata.Rel_X, jsdata.Rel_Y, jsdata.Rel_time);
        jsflag.new_relmove_cmd_received = 0;
    }
    if(jsflag.new_poscali_cmd_received)
    {
        Car_Poscali_Start_or_Stop(jsdata.poscali_enable);
        jsflag.new_poscali_cmd_received = 0;
    }
    if(jsflag.new_clear_gyroerr_cmd_received)
    {
        if(jsdata.clear_gyroerr_sta == 0)
        {
            LED1_ON;
            PID_En = 0;
            GyroYaw_SetZero_fastdelay();
            pid.integral = 0;
            pid.previous_error = 0;
        }
        else if (jsdata.clear_gyroerr_sta == 1)
        {
            LED1_OFF;
            GyroYaw_SetZero_fastdelay();
            pid.integral = 0;
            pid.previous_error = 0;
            PID_En = 1;
        }
        jsflag.new_clear_gyroerr_cmd_received = 0;
    }
    if(jsflag.new_LED_cmd_received)
    {
        CamLED_Toggle(jsdata.LED_sta);
        jsflag.new_LED_cmd_received = 0;
    }
    if(jsflag.new_rotate_cmd_received)
    {
        Car_Rotate(jsdata.rotate_angle, jsdata.rotate_speed);
        jsflag.new_rotate_cmd_received = 0;
    }
}

void PosCali_En_Switch_Task(void)
{
    if(PosCali_en && !flag.poscali_en)
    {
        PoscaliEnable(1);
        flag.poscali_en = true;
    }
    else if(!PosCali_en && flag.poscali_en)
    {
        PoscaliEnable(0);
        flag.poscali_en = false;
    }
}

void CamLED_En_Switch_Task(void)
{
    if(CamLED_en && !flag.camled_en)
    {
        CamLED_Toggle(1);
        flag.camled_en = true;
    }
    else if(!CamLED_en && flag.camled_en)
    {
        CamLED_Toggle(0);
        flag.camled_en = false;
    }
}

void CycleMove_En_Switch_Task(void)
{
    if(CycleMove_en)
    {
        Car_Absolute_Pos_Ctrl_Line(car.back_X, car.back_Y, car.back_time);
    }
}

void CarRotate_Task(void)
{
    if(flag.car_in_task == 3)
    {
        float Error = pid_rotate.setpoint - car.Current_YawAngle_Unlimited;
        if(Error > -1.0f && Error < 1.0f)
        {
            // PID_Init(&pid, 4.5f, 0.16f, 0.3f, car.set_yawangle, 0.01f);
            pid.integral = 0;
            pid.previous_error = 0;
            pid.setpoint = car.set_yawangle;
            flag.car_in_task = 0;
            Jetson_SendArray(RotateReached, sizeof(RotateReached));
        }
    }
}
