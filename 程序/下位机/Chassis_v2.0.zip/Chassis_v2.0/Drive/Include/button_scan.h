#ifndef __BUTTON_SCAN_H
#define __BUTTON_SCAN_H

#include "stm32f4xx.h" 
#include <stdbool.h>

// app�˰�ťID����
typedef enum 
{
    BTN_NONE = 0,
    BTN_P_A_L_MOVE,
    BTN_P_R_L_MOVE,
    BTN_BACK,
    BTN_YAW_SETZERO,
    BTN_APOS_SETZERO,
    BTN_ZEROBIASCALI,
    BTN_PGUP,
    BTN_PGDN,
    BTN_SAVE,
    BTN_P_NEXT,
    BTN_P_BACK,
    BTN_ARMTO1,
    BTN_ARMTO2,
    BTN_ARMTO3,
    BTN_ARMTO4,
    BTN_ROTATE,
    // �����°�ť�ڴ�����
} ButtonID;


//�����������ݱ���
extern bool P_A_L_Move, P_R_L_Move, Back, Yaw_SetZero, PID_En, World_En, Motor_En, Apos_SetZero, cPID_En, ZerobiasCali, PGUP, PGDN, 
            SAVE, P_mode, P_NEXT, P_BACK, ArmTo1, ArmTo2, ArmTo3, ArmTo4, PosCali_en, CamLED_en, CycleMove_en, rotate;
extern uint8_t P_A_L_t, P_R_L_t, Set_Time;
extern uint16_t P_A_L_x, P_A_L_y, Set_X, Set_Y, ro_v_limit;
extern int16_t Speed_X_x10, Speed_Y_x10, Kp_x1000, Ki_x1000, Kd_x1000, cKp_x1000, cKi_x10000, cKd_x1000, P_R_L_x, P_R_L_y, SetAngle;

void Button_Scan_Task(void);
void Bluetooth_Data_Receive_Task(void);


#endif
