#ifndef __CAMERALED_H
#define __CAMERALED_H

void CamLED_Init(void);
void CamLED_Toggle(uint8_t sta);

#endif
