#include "delay.h"
#include "stm32f4xx.h"

#define RCC_IIC_SCL RCC_AHB1Periph_GPIOB // �˿�ʱ��
#define IIC_SCL_PORT GPIOB               // �˿�
#define IIC_SCL GPIO_Pin_6               // ����

#define RCC_IIC_SDA RCC_AHB1Periph_GPIOB // �˿�ʱ��
#define IIC_SDA_PORT GPIOB              // �˿�
#define IIC_SDA GPIO_Pin_7               // ����

// IO��������
#define IIC_SCL_H IIC_SCL_PORT->BSRRH = IIC_SCL                 // SCL��1
#define IIC_SCL_L IIC_SCL_PORT->BSRRL = IIC_SCL                 // SCL��0
#define IIC_SDA_H IIC_SDA_PORT->BSRRH = IIC_SDA                 // SDA��1
#define IIC_SDA_L IIC_SDA_PORT->BSRRL = IIC_SDA                 // SDA��0
#define READ_SDA (IIC_SDA_PORT->IDR & IIC_SDA) ? 1 : 0          // ��ȡSDA���루IIC_SDA_PORT->IDR & IIC_SDA��ʾIIC_SDA�ڵ�IIC_SDA���ţ�

void iic_SDA(uint8_t x)
{
	if (x & 0X01)
    {
        IIC_SDA_H;
    }
    else
    {
        IIC_SDA_L;
    }
}

void SDA_OUT(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_IIC_SDA, ENABLE);
	GPIO_InitStructure.GPIO_Pin = IIC_SDA;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(IIC_SDA_PORT, &GPIO_InitStructure);
}

void SDA_IN(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_AHB1PeriphClockCmd(RCC_IIC_SDA, ENABLE);
	GPIO_InitStructure.GPIO_Pin = IIC_SDA;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_Init(IIC_SDA_PORT, &GPIO_InitStructure);
}

void IIC_init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    // GPIOʱ��
    RCC_AHB1PeriphClockCmd(RCC_IIC_SCL, ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_IIC_SDA, ENABLE);
    // GPIO��ʼ��
    GPIO_InitStructure.GPIO_Pin = IIC_SCL;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;      // ���ģʽ
    GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;     // ��©���
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; // �ٶ�
    GPIO_Init(IIC_SCL_PORT, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = IIC_SDA;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;      // ���ģʽ
    GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;     // ��©���
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz; // �ٶ�
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;       // ��������ʱ��Ч
    GPIO_Init(IIC_SDA_PORT, &GPIO_InitStructure);

    IIC_SCL_H;
    IIC_SDA_H;
}

void IIC_Start(void)
{
	// ���
	SDA_OUT();
	IIC_SDA_H;
	IIC_SCL_H;
	delay_us(4);
	IIC_SDA_L;// ����SDA
	delay_us(4);
	IIC_SCL_L;// ǯסIIC���ߣ�׼�����ͻ��������
}

void IIC_Stop(void)
{
	SDA_OUT();
	IIC_SCL_L;
	IIC_SDA_L;
	delay_us(4);
	IIC_SCL_H;
	IIC_SDA_H;
	delay_us(4);
}

void IIC_ACK(void)
{
	IIC_SCL_L;
	SDA_OUT();
	IIC_SDA_L;
	delay_us(1);
	IIC_SCL_H;
	delay_us(2);
	IIC_SCL_L;
}

void IIC_NACK(void)
{
	IIC_SCL_L;
	SDA_OUT();
	IIC_SDA_H;
	delay_us(1);
	IIC_SCL_H;
	delay_us(1);
	IIC_SCL_L;
}

uint8_t IIC_waitACK(void)
{
	uint8_t ucErrTime=0;
	SDA_IN();
	IIC_SDA_H;
	delay_us(1);
	IIC_SCL_H;
	delay_us(1);
	while(READ_SDA)
	{
		ucErrTime++;
		if(ucErrTime>250)
		{
			IIC_Stop();
			return 1;
		}
	}
	IIC_SCL_L;
	return 0;
}

void IIC_SendByte(uint8_t data)
{
    uint8_t t;
    
    for (t = 0; t < 8; t++)
    {
        iic_SDA((data & 0x80) >> 7);    /* ��λ�ȷ��� */
        delay_us(2);
        IIC_SCL_H;
        delay_us(2);
        IIC_SCL_L;
        data <<= 1;     /* ����1λ,������һ�η��� */
    }
    IIC_SDA_H;         /* �������, �����ͷ�SDA�� */
}

uint8_t IIC_ReadByte(uint8_t ack)
{
    uint8_t i, receive = 0;

    for (i = 0; i < 8; i++ )    /* ����1���ֽ����� */
    {
        receive <<= 1;  /* ��λ�����,�������յ�������λҪ���� */
        IIC_SCL_H;
        delay_us(2);

        if (READ_SDA)
        {
            receive++;
        }
        
        IIC_SCL_L;
        delay_us(2);
    }

    if (!ack)
    {
        IIC_NACK();     /* ����nACK */
    }
    else
    {
        IIC_ACK();      /* ����ACK */
    }

    return receive;
}
