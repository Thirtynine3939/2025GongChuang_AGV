#include "task.h"

volatile float ServoAngle[4] = {0, 0, 0, 0};
volatile uint8_t new_srevocmd_received = 0;

extern JetsonData jsdata;
extern JetsonFlag jsflag;
extern TxPack txpack;

uint8_t CarReached[4] = {0x39, 0xFF, 0xFF, 0x39}; //小车到位指令数组
uint8_t RotateReached[4] = {0x40, 0xFF, 0xFF, 0x40}; //小车旋转到位指令数组

void Jetson_Init_U5(void) 
{
    /* 开启时钟 */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5, ENABLE); // 开启 UART5 时钟
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE); // 开启 GPIOC 时钟
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE); // 开启 GPIOC 时钟

    /* GPIO 初始化 */
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2; //PD2 -> RX
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOD, &GPIO_InitStructure); // 将引脚 PD2 配置为复用

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12; //PC12 -> TX
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOC, &GPIO_InitStructure); // 将引脚 PC12 配置为复用

    // 配置引脚复用为 UART5
    GPIO_PinAFConfig(GPIOD, GPIO_PinSource2, GPIO_AF_UART5); // PA0 复用为 UART5_TX
    GPIO_PinAFConfig(GPIOC, GPIO_PinSource12, GPIO_AF_UART5); // PA1 复用为 UART5_RX

    /* UART 初始化 */
    USART_InitTypeDef USART_InitStructure;
    USART_InitStructure.USART_BaudRate = 115200; // 波特率
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None; // 无硬件流控制
    USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx; // 发送和接收模式
    USART_InitStructure.USART_Parity = USART_Parity_No; // 无奇偶校验
    USART_InitStructure.USART_StopBits = USART_StopBits_1; // 1 个停止位
    USART_InitStructure.USART_WordLength = USART_WordLength_8b; // 字长 8 位
    USART_Init(UART5, &USART_InitStructure); // 初始化 UART5

    /* 中断配置 */
    USART_ITConfig(UART5, USART_IT_RXNE, ENABLE); // 开启接收中断

    /* NVIC 配置 */
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel = UART5_IRQn; // UART5 中断
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1; // 抢占优先级
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0; // 响应优先级
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; // 使能中断
    NVIC_Init(&NVIC_InitStructure); // 初始化 NVIC

    /* UART5 使能 */
    USART_Cmd(UART5, ENABLE); // 使能 UART5

}

void Jetson_SendByte(uint8_t Byte) {
    USART_SendData(UART5, Byte);
    while (USART_GetFlagStatus(UART5, USART_FLAG_TXE) == RESET);
}

void Jetson_SendArray(uint8_t *array, uint16_t length) {
    for (uint16_t i = 0; i < length; i++) {
        Jetson_SendByte(array[i]);
    }
}

void PoscaliEnable(uint8_t sta)
{
    uint8_t cmd[4];
    cmd[0] = 0x93;
    cmd[1] = 0x11;
    cmd[2] = sta & 0xFF;
    cmd[3] = 0xFF;
    Jetson_SendArray(cmd, sizeof(cmd));
}

void PoscaliDirChoose(uint8_t dir)
{
    uint8_t cmd[4];
    cmd[0] = 0x93;
    cmd[1] = 0x12;
    cmd[2] = dir & 0xFF;
    cmd[3] = 0xFF;
    Jetson_SendArray(cmd, sizeof(cmd));
}

void DataProcess(uint8_t *data, uint16_t length)
{
    if(length == 9)
    {
        // uint8_t checksum = CalculateChecksum(data, length - 1);
        // if(checksum != data[length - 1])
        // {
        //     return;
        // }
        if(data[length - 1] != 0xFF)
        {
            return;
        }

        if(data[0] == 0x39 && data[1] == 0x41)
        {
            uint8_t addr = data[2];
            uint8_t ang10_l = data[3];
            uint8_t ang10_h = data[4];
            uint16_t ang10 = (uint16_t)((ang10_h << 8) | ang10_l);
            ServoAngle[addr - 1] = ((float)ang10 / 10.0f);
            new_srevocmd_received = addr;
        }
        else if(data[0] == 0x39 && data[1] == 0x31)
        {
            uint8_t circle_x10_l = data[2];
            uint8_t circle_x10_h = data[3];
            uint8_t circle_y10_l = data[4];
            uint8_t circle_y10_h = data[5];
            int16_t circle_x10 = (int16_t)((circle_x10_h << 8) | circle_x10_l);
            int16_t circle_y10 = (int16_t)((circle_y10_h << 8) | circle_y10_l);
            jsdata.circle_x = ((float)circle_x10 / 10.0f);
            jsdata.circle_y = ((float)circle_y10 / 10.0f);

            txpack.floats[1] = jsdata.circle_x;
            txpack.floats[2] = jsdata.circle_y;
        }
        else if(data[0] == 0x39 && data[1] == 0x32)
        {
            jsdata.poscali_enable = data[2];
            jsdata.poscali_dir = data[3];
            jsflag.new_poscali_cmd_received = 1;
        }
        else if(data[0] == 0x39 && data[1] == 0x51)
        {
            jsdata.clear_gyroerr_sta = data[2];
            jsflag.new_clear_gyroerr_cmd_received = 1;
        }
        else if(data[0] == 0x39 && data[1] == 0x21)
        {
            uint8_t X_l = data[2];
            uint8_t X_h = data[3];
            uint8_t Y_l = data[4];
            uint8_t Y_h = data[5];
            jsdata.Line_time = data[6];
            jsdata.Line_X = (uint16_t)((X_h << 8) | X_l);
            jsdata.Line_Y = (uint16_t)((Y_h << 8) | Y_l);
            jsflag.new_linemove_cmd_received = 1;
        }
        else if(data[0] == 0x39 && data[1] == 0x22)
        {
            uint8_t X_l = data[2];
            uint8_t X_h = data[3];
            uint8_t Y_l = data[4];
            uint8_t Y_h = data[5];
            jsdata.Rel_time = data[6];
            jsdata.Rel_X = (int16_t)((X_h << 8) | X_l);
            jsdata.Rel_Y = (int16_t)((Y_h << 8) | Y_l);
            jsflag.new_relmove_cmd_received = 1;
        }
        else if(data[0] == 0x39 && data[1] == 0x61)
        {
            uint8_t Angle_l = data[2];
            uint8_t Angle_h = data[3];
            jsdata.rotate_speed = data[4];

            jsdata.rotate_angle = (int16_t)((Angle_h << 8) | Angle_l);

            jsflag.new_rotate_cmd_received = 1;
        }
        else if(data[0] == 0x39 && data[1] == 0x71)
        {
            jsdata.LED_sta = data[2];
            jsflag.new_LED_cmd_received = 1;
        }
    }
}

void UART5_IRQHandler(void) 
{
    static uint8_t rx_buffer[9];	//数据包
    static uint8_t rx_index = 0;	//数据位
    static uint8_t state = 0; 		// 0: 寻找包头，1: 接收数据

    if (USART_GetITStatus(UART5, USART_IT_RXNE) != RESET) 
	{
        uint8_t data = USART_ReceiveData(UART5);

        if (state == 0) // 寻找包头
		{ 
            if (data == 0x39) 
			{
                rx_buffer[0] = data;
                rx_index = 1;
                state = 1;
            }
        } 
		else if (state == 1) // 接收数据
		{ 
            rx_buffer[rx_index++] = data;
            if (rx_index == 2 && rx_buffer[1] != 0x41 && 
                rx_buffer[1] != 0x31 && rx_buffer[1] != 0x21 && 
                rx_buffer[1] != 0x22 && rx_buffer[1] != 0x32 && 
                rx_buffer[1] != 0x51 && rx_buffer[1] != 0x61 &&
                rx_buffer[1] != 0x71) // 如果第二字节不是预设字节，则继续寻找下一个0x39
			{
                if (rx_buffer[1] == 0x39) 
				{
                    rx_index = 1;
                } 
				else 
				{
                    state = 0;
                    rx_index = 0;
                }
            } 
			else if (rx_index == 9) 
			{
                // ParseAndPrintData(rx_buffer, 11);
                DataProcess(rx_buffer, 9);
                rx_index = 0;
                state = 0;
            }
        }

        USART_ClearITPendingBit(UART5, USART_IT_RXNE);
    }
}
