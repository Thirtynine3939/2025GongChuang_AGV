#include "pid.h"

void PID_Init(PID_TypeDef* pid, float kp, float ki, float kd, float setpoint, float allowed_error) 
{
    pid->Kp = kp;
    pid->Ki = ki;
    pid->Kd = kd;
    pid->setpoint = setpoint;
    pid->integral = 0;
    pid->previous_error = 0;
    pid->allowed_error = allowed_error;
}

float PID_Compute(PID_TypeDef* pid, float current_value) 
{
    float error = pid->setpoint - current_value;
    pid->integral += error;
	
	if(pid->integral > 1000){pid->integral = 1000;}
	else if(pid->integral < -1000){pid->integral = -1000;}
	
    float derivative = (error - pid->previous_error);
    pid->previous_error = error;
	if(error < pid->allowed_error && error > -pid->allowed_error )
	{
		return 0;
	}
	else
	{
		return pid->Kp * error + pid->Ki * pid->integral + pid->Kd * derivative;
	}
}
