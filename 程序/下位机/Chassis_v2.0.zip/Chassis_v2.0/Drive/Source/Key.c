#include "stm32f4xx.h"               // Device header
#include "Delay.h"

#define Key1_Check GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_4)
#define Key2_Check GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_15)
//#define Key2_Check GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_9)
//#define Key3_Check GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_7)
//#define Key4_Check GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_13)

void Key_Init(void)
{
	RCC_AHB1PeriphClockCmd ( RCC_AHB1Periph_GPIOA, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
	GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_15;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
}



uint8_t Key_GetNum(void)
{
	static uint8_t Key1_Up = 1, Key2_Up = 1;
	if(Key1_Up && Key1_Check==0)
	{
		delay_ms(10);
		if(Key1_Check==0)
		{
			Key1_Up=0;
			return 1;
		}
	}
	else if(Key1_Check == 1)
	{
		Key1_Up=1;
	}
	
	if(Key2_Up && Key2_Check==0)
	{
		delay_ms(10);
		if(Key2_Check==0)
		{
			Key2_Up=0;
			return 2;
		}
	}
	else if(Key2_Check == 1)
	{
		Key2_Up=1;
	}
//	
//	if(Key3_Up && Key3_Check==0)
//	{
//		delay_ms(10);
//		if(Key3_Check==0)
//		{
//			Key3_Up=0;
//			return 3;
//		}
//	}
//	else if(Key3_Check == 1)
//	{
//		Key3_Up=1;
//	}
//	
//	if(Key4_Up && Key4_Check==0)
//	{
//		delay_ms(10);
//		if(Key4_Check==0)
//		{
//			Key4_Up=0;
//			return 4;
//		}
//	}
//	else if(Key4_Check == 1)
//	{
//		Key4_Up=1;
//	}
//	
	return 0;
}


