#ifndef __HWT101_H
#define __HWT101_H

#include "stm32f4xx.h"

typedef struct {
    uint32_t startSeconds;
    uint8_t  waitSeconds;
    uint8_t  elapsedSeconds;
    uint8_t  isActive;
    uint8_t  secondsCounter;
    uint8_t  finish_flag;
} ZeroBiasCal;

extern volatile float global_angle;
extern volatile uint8_t new_data_received;
extern volatile float angular_velocity_y;
extern volatile float angular_velocity_z;
extern uint8_t received_data_packet[11];

extern uint8_t reset_z_axis[5];
extern uint8_t zero_bias_get_mode[5];
extern uint8_t nomal_mode[5];
extern uint8_t restart_device[5];

void ZerobiasCal_Start(uint8_t time);

void Yaw_Receive_Task(void);

void HWT101_Init_U4(void);
void UART4_SendByte(uint8_t Byte);
 
void UART4_SendString(char *String);
void UART4_SendArray(uint8_t *array, uint16_t length);
void UART4_SendArray_fastdelay(uint8_t *array, uint16_t length);
 
void ParseAndPrintData(uint8_t *data, uint16_t length);
uint8_t CalculateChecksum(uint8_t *data, uint16_t length);
void GyroYaw_SetZero(void);
void GyroYaw_SetZero_fastdelay(void);


#endif
