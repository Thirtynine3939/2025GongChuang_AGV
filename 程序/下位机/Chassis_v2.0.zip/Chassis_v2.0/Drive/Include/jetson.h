#ifndef __JETSON_H
#define __JETSON_H

#include "stm32f4xx.h"

extern volatile float ServoAngle[4];
extern volatile uint8_t new_srevocmd_received;

extern uint8_t CarReached[4];
extern uint8_t RotateReached[4];

typedef struct 
{
    uint16_t Line_X;
    uint16_t Line_Y;
    uint8_t Line_time;
    int16_t Rel_X;
    int16_t Rel_Y;
    uint8_t Rel_time;
    float circle_x;
    float circle_y;
    uint8_t poscali_enable;
    uint8_t poscali_dir;
    uint8_t clear_gyroerr_sta;
    int16_t rotate_angle;
    uint8_t rotate_speed;
    uint8_t LED_sta;
} JetsonData;

typedef struct 
{
    uint8_t new_linemove_cmd_received;
    uint8_t new_relmove_cmd_received;
    uint8_t new_poscali_cmd_received;
    uint8_t new_clear_gyroerr_cmd_received;
    uint8_t new_rotate_cmd_received;
    uint8_t new_LED_cmd_received;
} JetsonFlag;

void Jetson_Init_U5(void);
void DataProcess(uint8_t *data, uint16_t length);
void Jetson_SendArray(uint8_t *array, uint16_t length);
void PoscaliEnable(uint8_t sta);
void PoscaliDirChoose(uint8_t dir);
float Cal_New_Angle(float current_angle);

#endif
