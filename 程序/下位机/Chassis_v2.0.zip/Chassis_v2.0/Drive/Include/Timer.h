#ifndef __TIMER_H
#define __TIMER_H

void Move_Time_TIM12_Init(uint16_t psc, uint16_t arr);
void Move_Time_Cmd(uint8_t state);
void Task_Backend_TIM11_Init(uint16_t psc, uint16_t arr);
void ZerobiasCali_TIM10_Init(uint16_t psc, uint16_t arr);

#endif
