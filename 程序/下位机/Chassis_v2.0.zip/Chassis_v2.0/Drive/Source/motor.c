#include "stm32f4xx.h"                  
#include "delay.h"
#include "motor.h"
#include "arm_math.h"
#include "valuepack.h"
#include <stdbool.h>

extern TxPack txpack;

int Pulse_Cnt=0;

extern volatile float Current_YawAngle;

uint8_t MotorA_Dir=2,MotorB_Dir=2,MotorC_Dir=2,MotorD_Dir=2;

//void TIM8_UP_TIM13_IRQHandler(void)
//{
//	if (TIM_GetITStatus(TIM13, TIM_IT_Update)!=RESET)
//	{	  
//		TIM_ClearITPendingBit(TIM13, TIM_IT_Update);		
//		if(MotorA_Dir == 1)
//		{
//			Pulse_Cnt++;
//		}
//		else if(MotorA_Dir == 0)
//		{
//			Pulse_Cnt--;
//		}
//	}
//}

void MotorA_Move(float speed)//rpm
{
	if (speed > -0.29f && speed < 0.29f)
    {
        TIM_Cmd(TIM13, DISABLE);
        return;
    }
	else
	{
		if(speed>0 && (MotorA_Dir==2 || !MotorA_Dir))
		{
			GPIO_SetBits(MotorA_DIR_PORT,MotorA_DIR);
			MotorA_Dir = 1; //��ʱ��
		}
		else if(speed<0 && (MotorA_Dir==2 || MotorA_Dir))
		{
			GPIO_ResetBits(MotorA_DIR_PORT,MotorA_DIR);
			MotorA_Dir = 0; //˳ʱ��
		}
		if(speed < 0)
		{
			speed = -speed;
		}
		if (speed > 500)
		{
			speed = 500;
		}

		TIM_SetCompare1(TIM13,((uint16_t)roundf((18750/speed)-1)+1)/2);
		TIM_SetAutoreload(TIM13,(uint16_t)roundf((18750/speed)-1));

		if ((TIM13->CR1 & TIM_CR1_CEN) == 0) 
		{
			TIM_Cmd(TIM13, ENABLE);
		}
	}
}
	
void MotorB_Move(float speed)
{
	if (speed > -0.29f && speed < 0.29f)
    {
        TIM_Cmd(TIM14, DISABLE);
        return;
    }
	else
	{
		if(speed>0 && (MotorB_Dir==2 || !MotorB_Dir))
		{
			GPIO_SetBits(MotorB_DIR_PORT,MotorB_DIR);
			MotorB_Dir = 1;
		}
		else if(speed<0 && (MotorB_Dir==2 || MotorB_Dir))
		{
			GPIO_ResetBits(MotorB_DIR_PORT,MotorB_DIR);
			speed = -speed;
			MotorB_Dir = 0;
		}
		if(speed < 0)
		{
			speed = -speed;
		}
		if (speed > 250)
		{
			speed = 250;
		}

		TIM_SetCompare1(TIM14,((uint16_t)roundf((18750/speed)-1)+1)/2);
		TIM_SetAutoreload(TIM14,(uint16_t)roundf((18750/speed)-1));

		if ((TIM14->CR1 & TIM_CR1_CEN) == 0) 
		{
			TIM_Cmd(TIM14, ENABLE);
		}
	}
}

void MotorC_Move(float speed)
{
	if (speed > -0.29f && speed < 0.29f)
    {
        TIM_Cmd(TIM3, DISABLE);
        return;
    }
	else
	{
		if(speed>0 && (MotorC_Dir==2 || !MotorC_Dir))
		{
			GPIO_SetBits(MotorC_DIR_PORT,MotorC_DIR);
			MotorC_Dir = 1;
		}
		else if(speed<0 && (MotorC_Dir==2 || MotorC_Dir))
		{
			GPIO_ResetBits(MotorC_DIR_PORT,MotorC_DIR);
			speed = -speed;
			MotorC_Dir = 0;
		}
		if(speed < 0)
		{
			speed = -speed;
		}
		if (speed > 250)
		{
			speed = 250;
		}

		TIM_SetCompare3(TIM3,((uint16_t)roundf((18750/speed)-1)+1)/2);
		TIM_SetAutoreload(TIM3,(uint16_t)roundf((18750/speed)-1));

		if ((TIM3->CR1 & TIM_CR1_CEN) == 0) 
		{
			TIM_Cmd(TIM3, ENABLE);
		}
	}
}

void MotorD_Move(float speed)
{
	if (speed > -0.29f && speed < 0.29f)
    {
        TIM_Cmd(TIM2, DISABLE);
        return;
    }
	else
	{
		if(speed>0 && (MotorD_Dir==2 || !MotorD_Dir))
		{
			GPIO_SetBits(MotorD_DIR_PORT,MotorD_DIR);
			MotorD_Dir = 1;
		}
		else if(speed<0 && (MotorD_Dir==2 || MotorD_Dir))
		{
			GPIO_ResetBits(MotorD_DIR_PORT,MotorD_DIR);
			speed = -speed;
			MotorD_Dir = 0;
		}
		if(speed < 0)
		{
			speed = -speed;
		}
		if (speed > 250)
		{
			speed = 250;
		}

		TIM_SetCompare1(TIM2,((uint16_t)roundf((18750/speed)-1)+1)/2);
		TIM_SetAutoreload(TIM2,(uint16_t)roundf((18750/speed)-1));

		if ((TIM2->CR1 & TIM_CR1_CEN) == 0) 
		{
			TIM_Cmd(TIM2, ENABLE);
		}
	}
}

void MotorA_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_OCInitTypeDef TIM_OCInitStructure;
//	NVIC_InitTypeDef   NVIC_InitStructure;
	
	RCC_AHB1PeriphClockCmd(RCC_MotorA_STP, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_MotorA_EN, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM13, ENABLE);
	
	//EN,DIR
	GPIO_InitStructure.GPIO_Pin 		= MotorA_EN | MotorA_DIR;
	GPIO_InitStructure.GPIO_Mode 		= GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType  		= GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed 		= GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_PuPd		= GPIO_PuPd_DOWN;
	GPIO_Init(MotorA_EN_PORT, &GPIO_InitStructure);
	
	//STP
	GPIO_InitStructure.GPIO_Pin 		= MotorA_STP;
	GPIO_InitStructure.GPIO_Mode 		= GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Speed 		= GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_OType  		= GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd		= GPIO_PuPd_DOWN;
	GPIO_Init(MotorA_STP_PORT, &GPIO_InitStructure);
	
	GPIO_PinAFConfig(MotorA_STP_PORT, MotorA_STP_SOURCE, GPIO_AF_TIM13);
	
	//��ʱ��	
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_ClockDivision = 0;
	TIM_TimeBaseInitStructure.TIM_Prescaler = 84 - 1;		//PSC
	TIM_TimeBaseInitStructure.TIM_Period = 65536 - 1;			//ARR
	TIM_TimeBaseInit(TIM13, &TIM_TimeBaseInitStructure);
	
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; //PWMģʽ1������CCRʱΪ��Ч��ƽ
 	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; //����Ƚ�ʹ��
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; //��Ч��ƽΪ�ߵ�ƽ
	TIM_OCInitStructure.TIM_Pulse = 32768;		//CCR
	TIM_OC1Init(TIM13, &TIM_OCInitStructure); 
	TIM_OC1PreloadConfig(TIM13, TIM_OCPreload_Enable);	
	TIM_ARRPreloadConfig(TIM13,ENABLE);
//	NVIC_InitStructure.NVIC_IRQChannel = TIM8_UP_TIM13_IRQn;
//    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1; 
//    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1; 
//    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; 
//    NVIC_Init(&NVIC_InitStructure);

//	TIM_UpdateRequestConfig(TIM13,TIM_UpdateSource_Regular);
//	TIM_ClearITPendingBit(TIM13,TIM_IT_Update);
//	TIM_ITConfig(TIM13,TIM_IT_Update,ENABLE);  // ʹ�ܸ����ж�

//	TIM_Cmd(TIM13, ENABLE);
}

void MotorB_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_OCInitTypeDef TIM_OCInitStructure;
//	NVIC_InitTypeDef   NVIC_InitStructure;
	
	RCC_AHB1PeriphClockCmd(RCC_MotorB_EN, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_MotorB_STP, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM14, ENABLE);
	
	GPIO_PinAFConfig(MotorB_STP_PORT, MotorB_STP_SOURCE, GPIO_AF_TIM14);
	
	//EN,DIR
	GPIO_InitStructure.GPIO_Pin 		= MotorB_EN | MotorB_DIR;
	GPIO_InitStructure.GPIO_Mode 		= GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType  		= GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed 		= GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_PuPd		= GPIO_PuPd_DOWN;
	GPIO_Init(MotorB_EN_PORT, &GPIO_InitStructure);
	
	//STP
	GPIO_InitStructure.GPIO_Pin 		= MotorB_STP;
	GPIO_InitStructure.GPIO_Mode 		= GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_OType  		= GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed 		= GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_PuPd		= GPIO_PuPd_DOWN;
	GPIO_Init(MotorB_STP_PORT, &GPIO_InitStructure);
	
	//��ʱ��
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_Prescaler = 84 - 1;		//PSC
	TIM_TimeBaseInitStructure.TIM_Period = 65536 - 1;			//ARR
	TIM_TimeBaseInit(TIM14, &TIM_TimeBaseInitStructure);
	
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; //PWMģʽ1������CCRʱΪ��Ч��ƽ
 	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; //����Ƚ�ʹ��
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; //��Ч��ƽΪ�ߵ�ƽ
	TIM_OCInitStructure.TIM_Pulse = 32768;		//CCR
	TIM_OC1Init(TIM14, &TIM_OCInitStructure); 
	TIM_OC1PreloadConfig(TIM14, TIM_OCPreload_Enable);
	TIM_ARRPreloadConfig(TIM14,ENABLE);
//	NVIC_InitStructure.NVIC_IRQChannel = TIM8_TRG_COM_TIM14_IRQn;
//    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1; 
//    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1; 
//    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; 
//    NVIC_Init(&NVIC_InitStructure);

//	TIM_UpdateRequestConfig(TIM14,TIM_UpdateSource_Regular);
//	TIM_ClearITPendingBit(TIM14,TIM_IT_Update);
//	TIM_ITConfig(TIM14,TIM_IT_Update,ENABLE);  // ʹ�ܸ����ж�
	
//	TIM_Cmd(TIM14, ENABLE);
}

void MotorC_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_OCInitTypeDef TIM_OCInitStructure;
//	NVIC_InitTypeDef   NVIC_InitStructure;
	
	RCC_AHB1PeriphClockCmd(RCC_MotorC_STP, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_MotorC_DIR, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
	
	//EN,DIR
	GPIO_InitStructure.GPIO_Pin 		= MotorC_EN | MotorC_DIR;
	GPIO_InitStructure.GPIO_Mode 		= GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType  		= GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed 		= GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_PuPd		= GPIO_PuPd_DOWN;
	GPIO_Init(MotorC_EN_PORT, &GPIO_InitStructure);
	
	//STP
	GPIO_InitStructure.GPIO_Pin 		= MotorC_STP;
	GPIO_InitStructure.GPIO_Mode 		= GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Speed 		= GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_OType  		= GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd		= GPIO_PuPd_DOWN;
	GPIO_Init(MotorC_STP_PORT, &GPIO_InitStructure);
	
	GPIO_PinAFConfig(MotorC_STP_PORT, MotorC_STP_SOURCE, GPIO_AF_TIM3);
	
	//��ʱ��	
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_ClockDivision = 0;
	TIM_TimeBaseInitStructure.TIM_Prescaler = 84 - 1;		//PSC
	TIM_TimeBaseInitStructure.TIM_Period = 65536 - 1;			//ARR
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseInitStructure);
	
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; //PWMģʽ1������CCRʱΪ��Ч��ƽ
 	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; //����Ƚ�ʹ��
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; //��Ч��ƽΪ�ߵ�ƽ
	TIM_OCInitStructure.TIM_Pulse = 32768;		//CCR
	TIM_OC3Init(TIM3, &TIM_OCInitStructure); 
	TIM_OC3PreloadConfig(TIM3, TIM_OCPreload_Enable);	
	TIM_ARRPreloadConfig(TIM3,ENABLE);
//	NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
//    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1; 
//    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1; 
//    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; 
//    NVIC_Init(&NVIC_InitStructure);

//	TIM_UpdateRequestConfig(TIM3,TIM_UpdateSource_Regular);
//	TIM_ClearITPendingBit(TIM3,TIM_IT_Update);
//	TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE);  // ʹ�ܸ����ж�

//	TIM_Cmd(TIM3, ENABLE);
}

void MotorD_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_OCInitTypeDef TIM_OCInitStructure;
//	NVIC_InitTypeDef   NVIC_InitStructure;
	
	RCC_AHB1PeriphClockCmd(RCC_MotorD_STP, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_MotorD_EN, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
	
	//EN,DIR
	GPIO_InitStructure.GPIO_Pin 		= MotorD_EN | MotorD_DIR;
	GPIO_InitStructure.GPIO_Mode 		= GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType  		= GPIO_OType_PP;
	GPIO_InitStructure.GPIO_Speed 		= GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_PuPd		= GPIO_PuPd_DOWN;
	GPIO_Init(MotorD_EN_PORT, &GPIO_InitStructure);
	
	//STP
	GPIO_InitStructure.GPIO_Pin 		= MotorD_STP;
	GPIO_InitStructure.GPIO_Mode 		= GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Speed 		= GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_OType  		= GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd		= GPIO_PuPd_DOWN;
	GPIO_Init(MotorD_STP_PORT, &GPIO_InitStructure);
	
	GPIO_PinAFConfig(MotorD_STP_PORT, MotorD_STP_SOURCE, GPIO_AF_TIM2);
	
	//��ʱ��	
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStructure.TIM_ClockDivision = 0;
	TIM_TimeBaseInitStructure.TIM_Prescaler = 84 - 1;		//PSC
	TIM_TimeBaseInitStructure.TIM_Period = 65536 - 1;			//ARR
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStructure);
	
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; //PWMģʽ1������CCRʱΪ��Ч��ƽ
 	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; //����Ƚ�ʹ��
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; //��Ч��ƽΪ�ߵ�ƽ
	TIM_OCInitStructure.TIM_Pulse = 32768;		//CCR
	TIM_OC1Init(TIM2, &TIM_OCInitStructure); 
	TIM_OC1PreloadConfig(TIM2, TIM_OCPreload_Enable);	
	
	TIM_ARRPreloadConfig(TIM2,ENABLE);
//	NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
//    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1; 
//    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1; 
//    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; 
//    NVIC_Init(&NVIC_InitStructure);

//	TIM_UpdateRequestConfig(TIM2,TIM_UpdateSource_Regular);
//	TIM_ClearITPendingBit(TIM2,TIM_IT_Update);
//	TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE);  // ʹ�ܸ����ж�

//	TIM_Cmd(TIM2, ENABLE);
}

void Motors_Init(void)
{
	MotorA_Init();
	MotorB_Init();
	MotorC_Init();
	MotorD_Init();
}
