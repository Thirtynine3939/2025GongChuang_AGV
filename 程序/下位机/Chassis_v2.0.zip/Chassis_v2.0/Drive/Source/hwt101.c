#include "task.h"

extern RxPack rxpack;
extern TxPack txpack;
extern CAR car;
extern ZeroBiasCal zbc;
extern PID_TypeDef pid;
extern PID_TypeDef pid_rotate;

volatile float global_angle = 0.0f;
volatile uint8_t new_data_received = 0;
volatile float angular_velocity_y = 0.0f;
volatile float angular_velocity_z = 0.0f;
uint8_t received_data_packet[11] = {0};

// ������������
//�����Ĵ��� FF AA 69 88 B5
//Z��Ƕȹ���FF AA 76 00 00
//����100HZ��� FF AA 03 09 00
//���ò�����115200 FF AA 04 06 00
//���� FF AA 00 00 00
//���� FF AA 00 FF 00
uint8_t unlock_register[] = {0xFF, 0xAA, 0x69, 0x88, 0xB5};
uint8_t reset_z_axis[] = {0xFF, 0xAA, 0x76, 0x00, 0x00};
uint8_t set_output_100Hz[] = {0xFF, 0xAA, 0x03, 0x09, 0x00};
uint8_t set_baudrate_115200[] = {0xFF, 0xAA, 0x04, 0x06, 0x00};
uint8_t save_settings[] = {0xFF, 0xAA, 0x00, 0x00, 0x00};
uint8_t restart_device[] = {0xFF, 0xAA, 0x00, 0xFF, 0x00};
uint8_t zero_bias_get_mode[] = {0xFF, 0xAA, 0x48, 0x01, 0x00};
uint8_t nomal_mode[] = {0xFF, 0xAA, 0x48, 0x00, 0x00};

void GyroYaw_SetZero(void)
{
    if((pid_rotate.setpoint > 0.1f || pid_rotate.setpoint < -0.1f) || 
		(pid.setpoint > 0.1f || pid.setpoint < -0.1f)) return;
    UART4_SendArray(reset_z_axis, sizeof(reset_z_axis));
}

void GyroYaw_SetZero_fastdelay(void)
{
    if((pid_rotate.setpoint > 0.1f || pid_rotate.setpoint < -0.1f) || 
		(pid.setpoint > 0.1f || pid.setpoint < -0.1f)) return;
    UART4_SendArray_fastdelay(reset_z_axis, sizeof(reset_z_axis));
}

void ZerobiasCal_Start(uint8_t time)
{
    UART4_SendArray(zero_bias_get_mode, sizeof(zero_bias_get_mode));
    
    zbc.startSeconds = zbc.secondsCounter;
    zbc.waitSeconds = time;
    zbc.elapsedSeconds = 0;
    zbc.isActive = 1;
    
    txpack.bytes[0] = 0; // ��ʼ��ʱ��
    TIM_Cmd(TIM10, ENABLE);
}

float Cal_New_Angle(float current_angle)
{
	static float last_angle=0;
	float delat_angle = current_angle - last_angle;
	if(delat_angle>180)
	{
		current_angle-=360;
	}
	else if(delat_angle<-180)
	{
		current_angle+=360;
	}
	last_angle=current_angle;
	return current_angle;
}

void Yaw_Receive_Task(void)
{
    if(new_data_received)
    {
        new_data_received = 0;
        car.Current_YawAngle = global_angle;
        car.Current_YawAngle_Unlimited = Cal_New_Angle(car.Current_YawAngle);
        txpack.floats[0] = car.Current_YawAngle_Unlimited;
    }
}

void UART4_SendByte(uint8_t Byte) {
    USART_SendData(UART4, Byte);
    while (USART_GetFlagStatus(UART4, USART_FLAG_TXE) == RESET);
}

void UART4_SendArray(uint8_t *array, uint16_t length) {
    for (uint16_t i = 0; i < length; i++) {
        UART4_SendByte(array[i]);
    }
    UART4_SendByte(0x0D); // ���ͻس���
    UART4_SendByte(0x0A); // ���ͻ��з�
    delay_ms(200);
}

void UART4_SendArray_fastdelay(uint8_t *array, uint16_t length) 
{
    for (uint16_t i = 0; i < length; i++) {
        UART4_SendByte(array[i]);
    }
    UART4_SendByte(0x0D); // ���ͻس���
    UART4_SendByte(0x0A); // ���ͻ��з�
    delay_ms(10); // ������ʱ
}


void HWT101_Init_U4(void) 
{
    /* ����ʱ�� */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, ENABLE); // ���� UART4 ʱ��
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE); // ���� GPIOA ʱ��

    /* GPIO ��ʼ�� */
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1; // PA0 -> TX, PA1 -> RX
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOA, &GPIO_InitStructure); // ������ PA0, PA1 ����Ϊ����

    // �������Ÿ���Ϊ UART4
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource0, GPIO_AF_UART4); // PA0 ����Ϊ UART4_TX
    GPIO_PinAFConfig(GPIOA, GPIO_PinSource1, GPIO_AF_UART4); // PA1 ����Ϊ UART4_RX

    /* UART ��ʼ�� */
    USART_InitTypeDef USART_InitStructure;
    USART_InitStructure.USART_BaudRate = 115200; // ������
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None; // ��Ӳ��������
    USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx; // ���ͺͽ���ģʽ
    USART_InitStructure.USART_Parity = USART_Parity_No; // ����żУ��
    USART_InitStructure.USART_StopBits = USART_StopBits_1; // 1 ��ֹͣλ
    USART_InitStructure.USART_WordLength = USART_WordLength_8b; // �ֳ� 8 λ
    USART_Init(UART4, &USART_InitStructure); // ��ʼ�� UART4

    /* �ж����� */
    USART_ITConfig(UART4, USART_IT_RXNE, ENABLE); // ���������ж�

    /* NVIC ���� */
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_InitStructure.NVIC_IRQChannel = UART4_IRQn; // UART4 �ж�
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1; // ��ռ���ȼ�
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1; // ��Ӧ���ȼ�
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; // ʹ���ж�
    NVIC_Init(&NVIC_InitStructure); // ��ʼ�� NVIC

    /* UART4 ʹ�� */
    USART_Cmd(UART4, ENABLE); // ʹ�� UART4

    // ������������
    UART4_SendArray(unlock_register, sizeof(unlock_register));
    UART4_SendArray(reset_z_axis, sizeof(reset_z_axis));
    UART4_SendArray(set_output_100Hz, sizeof(set_output_100Hz));
    UART4_SendArray(set_baudrate_115200, sizeof(set_baudrate_115200));
    UART4_SendArray(save_settings, sizeof(save_settings));
    UART4_SendArray(restart_device, sizeof(restart_device));
	
	// USART_Cmd(UART4, DISABLE);
}



void UART4_SendString(char *String) {
    uint8_t i = 0;
    while (String[i]) {
        UART4_SendByte(String[i]);
        i++;
    }
}

uint8_t CalculateChecksum(uint8_t *data, uint16_t length) //У��ͼ���
{
    uint8_t checksum = 0;
    for (uint16_t i = 0; i < length; i++) 
	{
        checksum += data[i];
    }
    return checksum;
}

void ParseAndPrintData(uint8_t *data, uint16_t length) 
{
    if (length == 11) 
	{
        uint8_t checksum = CalculateChecksum(data, length - 1);
        if (checksum != data[length - 1]) 
		{
            return;
        }

        if (data[0] == 0x55 && data[1] == 0x53) 
		{
            uint8_t yaw_l = data[6];
            uint8_t yaw_h = data[7];
            int16_t yaw = (int16_t)((yaw_h << 8) | yaw_l);

            float angle = ((float)yaw / 32768) * 180;
            global_angle = angle;
            new_data_received = 1;
        } 
		else if (data[0] == 0x55 && data[1] == 0x52) 
		{
            uint8_t wy_l = data[4];
            uint8_t wy_h = data[5];
            int16_t wy = (int16_t)((wy_h << 8) | wy_l);
            angular_velocity_y = ((float)wy / 32768) * 2000;

            uint8_t wz_l = data[6];
            uint8_t wz_h = data[7];
            int16_t wz = (int16_t)((wz_h << 8) | wz_l);
            angular_velocity_z = ((float)wz / 32768) * 2000;

            new_data_received = 1;
        }
    }
}


void UART4_IRQHandler(void) 
{
    static uint8_t rx_buffer[11];	//���ݰ�
    static uint8_t rx_index = 0;	//����λ
    static uint8_t state = 0; 		// 0: Ѱ�Ұ�ͷ��1: ��������

    if (USART_GetITStatus(UART4, USART_IT_RXNE) != RESET) 
	{
        uint8_t data = USART_ReceiveData(UART4);

        if (state == 0) // Ѱ�Ұ�ͷ
		{ 
            if (data == 0x55) 
			{
                rx_buffer[0] = data;
                rx_index = 1;
                state = 1;
            }
        } 
		else if (state == 1) // ��������
		{ 
            rx_buffer[rx_index++] = data;
            if (rx_index == 2 && rx_buffer[1] != 0x53 /* && rx_buffer[1] != 0x52 */) // ����ڶ��ֽڲ���0x53��0x52�������Ѱ����һ��0x55
			{
                if (rx_buffer[1] == 0x55) 
				{
                    rx_index = 1;
                } 
				else 
				{
                    state = 0;
                    rx_index = 0;
                }
            } 
			else if (rx_index == 11) 
			{
                ParseAndPrintData(rx_buffer, 11);
                rx_index = 0;
                state = 0;
            }
        }

        USART_ClearITPendingBit(UART4, USART_IT_RXNE);
    }
}






